import os
import logging
import re
from pytube import YouTube
from datetime import datetime

logger = logging.getLogger(__name__)

class YouTubeDownloader:
    """Class to handle YouTube video downloads"""
    
    def __init__(self):
        """Initialize the YouTube downloader with a downloads directory"""
        self.download_dir = os.path.join(os.getcwd(), 'downloads')
        
        # Create downloads directory if it doesn't exist
        if not os.path.exists(self.download_dir):
            os.makedirs(self.download_dir)
            
        logger.debug(f"YouTube Downloader initialized with download directory: {self.download_dir}")
    
    def validate_url(self, url):
        """Check if the URL is a valid YouTube URL
        
        Args:
            url (str): The URL to validate
            
        Returns:
            bool: True if the URL is valid, False otherwise
        """
        youtube_regex = r'(https?://)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)/(watch\?v=|embed/|v/|.+\?v=)?([^&=%\?]{11})'
        match = re.match(youtube_regex, url)
        return match is not None
    
    def download_video(self, url, download_type='video'):
        """Download a video from YouTube
        
        Args:
            url (str): The YouTube URL
            download_type (str): Type of download - 'video', 'audio', or 'both'
            
        Returns:
            dict: Dictionary containing status, file_path, and message
        """
        try:
            if not self.validate_url(url):
                return {
                    'status': 'error',
                    'file_path': None,
                    'message': 'Invalid YouTube URL'
                }
            
            yt = YouTube(url)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            if download_type == 'audio':
                # Download audio only
                stream = yt.streams.filter(only_audio=True).first()
                file_name = f"{yt.title.replace(' ', '_')}_{timestamp}.mp3"
                file_path = os.path.join(self.download_dir, file_name)
                
                stream.download(output_path=self.download_dir, filename=file_name)
                logger.info(f"Downloaded audio: {file_name}")
                
                return {
                    'status': 'success',
                    'file_path': file_path,
                    'message': f'Audio downloaded successfully: {yt.title}'
                }
                
            elif download_type == 'video':
                # Download video (with audio)
                stream = yt.streams.filter(progressive=True, file_extension='mp4').order_by('resolution').desc().first()
                file_name = f"{yt.title.replace(' ', '_')}_{timestamp}.mp4"
                file_path = os.path.join(self.download_dir, file_name)
                
                stream.download(output_path=self.download_dir, filename=file_name)
                logger.info(f"Downloaded video: {file_name}")
                
                return {
                    'status': 'success',
                    'file_path': file_path,
                    'message': f'Video downloaded successfully: {yt.title}'
                }
                
            elif download_type == 'both':
                # Download both audio and video separately
                audio_stream = yt.streams.filter(only_audio=True).first()
                video_stream = yt.streams.filter(progressive=True, file_extension='mp4').order_by('resolution').desc().first()
                
                audio_file_name = f"{yt.title.replace(' ', '_')}_{timestamp}_audio.mp3"
                video_file_name = f"{yt.title.replace(' ', '_')}_{timestamp}_video.mp4"
                
                audio_file_path = os.path.join(self.download_dir, audio_file_name)
                video_file_path = os.path.join(self.download_dir, video_file_name)
                
                audio_stream.download(output_path=self.download_dir, filename=audio_file_name)
                video_stream.download(output_path=self.download_dir, filename=video_file_name)
                
                logger.info(f"Downloaded audio and video: {audio_file_name}, {video_file_name}")
                
                return {
                    'status': 'success',
                    'file_paths': {
                        'audio': audio_file_path,
                        'video': video_file_path
                    },
                    'message': f'Audio and video downloaded successfully: {yt.title}'
                }
            
            else:
                return {
                    'status': 'error',
                    'file_path': None,
                    'message': f'Invalid download type: {download_type}'
                }
                
        except Exception as e:
            logger.error(f"Error downloading video: {str(e)}")
            return {
                'status': 'error',
                'file_path': None,
                'message': f'Error downloading: {str(e)}'
            }
    
    def get_video_info(self, url):
        """Get information about a YouTube video
        
        Args:
            url (str): The YouTube URL
            
        Returns:
            dict: Dictionary containing video information
        """
        try:
            if not self.validate_url(url):
                return {
                    'status': 'error',
                    'message': 'Invalid YouTube URL'
                }
            
            yt = YouTube(url)
            
            info = {
                'status': 'success',
                'title': yt.title,
                'description': yt.description[:100] + '...' if len(yt.description) > 100 else yt.description,
                'author': yt.author,
                'length': self._format_duration(yt.length),
                'views': yt.views,
                'publish_date': yt.publish_date.strftime('%Y-%m-%d') if yt.publish_date else 'Unknown',
                'thumbnail_url': yt.thumbnail_url
            }
            
            return info
            
        except Exception as e:
            logger.error(f"Error fetching video info: {str(e)}")
            return {
                'status': 'error',
                'message': f'Error fetching video info: {str(e)}'
            }
    
    def _format_duration(self, seconds):
        """Format duration from seconds to mm:ss or hh:mm:ss
        
        Args:
            seconds (int): Duration in seconds
            
        Returns:
            str: Formatted duration string
        """
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        if hours > 0:
            return f"{int(hours)}:{int(minutes):02d}:{int(seconds):02d}"
        else:
            return f"{int(minutes):02d}:{int(seconds):02d}"
