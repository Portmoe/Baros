import os
import logging
from flask import Flask, request, render_template, jsonify, flash, redirect, url_for, session
from whatsapp_bot import WhatsAppBot
from command_handler import CommandHandler

# Configure logging
logging.basicConfig(level=logging.DEBUG, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Initialize WhatsApp bot
whatsapp_bot = WhatsAppBot()
command_handler = CommandHandler(whatsapp_bot)

@app.route('/')
def index():
    """Render the main index page"""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """Render the dashboard page with bot statistics"""
    stats = whatsapp_bot.get_stats()
    return render_template('dashboard.html', stats=stats)

@app.route('/webhook', methods=['POST'])
def webhook():
    """Handle incoming webhook events from WhatsApp"""
    try:
        data = request.json
        logger.debug(f"Received webhook data: {data}")
        
        # Handle the incoming message
        if 'messages' in data and len(data['messages']) > 0:
            for message in data['messages']:
                sender = message.get('from', '')
                message_body = message.get('body', '')
                
                # Process the command
                response = command_handler.process_command(sender, message_body)
                
                # Send the response back
                if response:
                    whatsapp_bot.send_message(sender, response)
        
        return jsonify({"status": "success"}), 200
    except Exception as e:
        logger.error(f"Error processing webhook: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/send_message', methods=['POST'])
def send_message():
    """API endpoint to manually send a message to a number"""
    try:
        number = request.form.get('number')
        message = request.form.get('message')
        
        if not number or not message:
            flash('Please provide both number and message', 'danger')
            return redirect(url_for('dashboard'))
            
        # Send the message
        result = whatsapp_bot.send_message(number, message)
        
        if result:
            flash('Message sent successfully!', 'success')
        else:
            flash('Failed to send message', 'danger')
            
        return redirect(url_for('dashboard'))
    except Exception as e:
        logger.error(f"Error sending message: {str(e)}")
        flash(f'Error: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    return render_template('index.html', error="Page not found"), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    return render_template('index.html', error="Server error occurred"), 500
