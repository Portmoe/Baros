import os
import logging
import requests
import json
from datetime import datetime

logger = logging.getLogger(__name__)

class WhatsAppBot:
    """WhatsApp Bot for handling message sending and receiving"""
    
    def __init__(self):
        """Initialize the WhatsApp Bot with API credentials"""
        self.api_key = os.environ.get("WHATSAPP_API_KEY", "")
        self.api_url = os.environ.get("WHATSAPP_API_URL", "https://api.whatsapp.com/v1")
        self.phone_number_id = os.environ.get("WHATSAPP_PHONE_NUMBER_ID", "")
        self.verify_token = os.environ.get("WHATSAPP_VERIFY_TOKEN", "")
        
        # Stats tracking
        self.messages_received = 0
        self.messages_sent = 0
        self.commands_processed = 0
        self.downloads_completed = 0
        self.errors_encountered = 0
        self.start_time = datetime.now()
        
        logger.debug("WhatsApp Bot initialized")
    
    def send_message(self, to_number, message_text):
        """Send a message to a WhatsApp number
        
        Args:
            to_number (str): The recipient's phone number
            message_text (str): The message text to send
            
        Returns:
            bool: True if message was sent successfully, False otherwise
        """
        try:
            # Ensure number is in international format without +
            if to_number.startswith('+'):
                to_number = to_number[1:]
                
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            data = {
                'messaging_product': 'whatsapp',
                'to': to_number,
                'type': 'text',
                'text': {
                    'body': message_text
                }
            }
            
            url = f"{self.api_url}/messages"
            response = requests.post(url, headers=headers, data=json.dumps(data))
            
            if response.status_code == 200:
                self.messages_sent += 1
                logger.debug(f"Message sent to {to_number}: {message_text[:50]}...")
                return True
            else:
                logger.error(f"Failed to send message. Status code: {response.status_code}, Response: {response.text}")
                self.errors_encountered += 1
                return False
                
        except Exception as e:
            logger.error(f"Error sending message: {str(e)}")
            self.errors_encountered += 1
            return False
    
    def send_file(self, to_number, file_path, caption=""):
        """Send a file to a WhatsApp number
        
        Args:
            to_number (str): The recipient's phone number
            file_path (str): The path to the file to send
            caption (str): Optional caption for the file
            
        Returns:
            bool: True if file was sent successfully, False otherwise
        """
        try:
            # Ensure number is in international format without +
            if to_number.startswith('+'):
                to_number = to_number[1:]
                
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            # Determine media type based on file extension
            file_extension = file_path.split('.')[-1].lower()
            if file_extension in ['mp4', 'avi', 'mov']:
                media_type = 'video'
            elif file_extension in ['jpg', 'jpeg', 'png']:
                media_type = 'image'
            elif file_extension in ['mp3', 'ogg', 'wav']:
                media_type = 'audio'
            else:
                media_type = 'document'
                
            # For simplicity, we're assuming the file is hosted somewhere and accessible via URL
            # In a real implementation, you'd need to upload the file to WhatsApp's servers first
            data = {
                'messaging_product': 'whatsapp',
                'to': to_number,
                'type': media_type,
                media_type: {
                    'link': file_path,
                    'caption': caption
                }
            }
            
            url = f"{self.api_url}/messages"
            response = requests.post(url, headers=headers, data=json.dumps(data))
            
            if response.status_code == 200:
                self.messages_sent += 1
                logger.debug(f"File sent to {to_number}: {file_path}")
                return True
            else:
                logger.error(f"Failed to send file. Status code: {response.status_code}, Response: {response.text}")
                self.errors_encountered += 1
                return False
                
        except Exception as e:
            logger.error(f"Error sending file: {str(e)}")
            self.errors_encountered += 1
            return False
    
    def get_stats(self):
        """Get bot statistics
        
        Returns:
            dict: Dictionary containing bot statistics
        """
        uptime_seconds = (datetime.now() - self.start_time).total_seconds()
        hours, remainder = divmod(uptime_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        return {
            'messages_received': self.messages_received,
            'messages_sent': self.messages_sent,
            'commands_processed': self.commands_processed,
            'downloads_completed': self.downloads_completed,
            'errors_encountered': self.errors_encountered,
            'uptime': f"{int(hours)}h {int(minutes)}m {int(seconds)}s",
            'start_time': self.start_time.strftime('%Y-%m-%d %H:%M:%S')
        }
    
    def increment_received(self):
        """Increment the messages received counter"""
        self.messages_received += 1
    
    def increment_commands(self):
        """Increment the commands processed counter"""
        self.commands_processed += 1
    
    def increment_downloads(self):
        """Increment the downloads completed counter"""
        self.downloads_completed += 1
