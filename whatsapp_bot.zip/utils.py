import os
import logging
import re
import time
from datetime import datetime

logger = logging.getLogger(__name__)

def clean_filename(filename):
    """Clean a filename to be safe for the file system
    
    Args:
        filename (str): The filename to clean
        
    Returns:
        str: Cleaned filename
    """
    # Replace special characters with underscores
    cleaned = re.sub(r'[\\/*?:"<>|]', '_', filename)
    # Replace multiple spaces with a single underscore
    cleaned = re.sub(r'\s+', '_', cleaned)
    return cleaned

def format_time(seconds):
    """Format seconds to a human-readable time string
    
    Args:
        seconds (int): Time in seconds
        
    Returns:
        str: Formatted time string (HH:MM:SS)
    """
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    if hours > 0:
        return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"
    else:
        return f"{int(minutes):02d}:{int(seconds):02d}"

def ensure_dir(directory):
    """Ensure a directory exists, creating it if necessary
    
    Args:
        directory (str): Directory path
        
    Returns:
        bool: True if directory exists or was created, False otherwise
    """
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
        return True
    except Exception as e:
        logger.error(f"Error creating directory {directory}: {str(e)}")
        return False

def get_file_size_mb(file_path):
    """Get the size of a file in megabytes
    
    Args:
        file_path (str): Path to the file
        
    Returns:
        float: File size in MB
    """
    try:
        size_bytes = os.path.getsize(file_path)
        size_mb = size_bytes / (1024 * 1024)
        return round(size_mb, 2)
    except Exception as e:
        logger.error(f"Error getting file size for {file_path}: {str(e)}")
        return 0

def create_timestamp_filename(base_name, extension):
    """Create a filename with a timestamp
    
    Args:
        base_name (str): Base name for the file
        extension (str): File extension
        
    Returns:
        str: Filename with timestamp
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{clean_filename(base_name)}_{timestamp}.{extension}"

def retry_operation(operation, max_retries=3, delay=1):
    """Retry an operation multiple times
    
    Args:
        operation (callable): Function to retry
        max_retries (int): Maximum number of retry attempts
        delay (int): Delay in seconds between retries
        
    Returns:
        mixed: Result of the operation or None if all retries failed
    """
    retries = 0
    last_error = None
    
    while retries < max_retries:
        try:
            return operation()
        except Exception as e:
            last_error = e
            retries += 1
            if retries < max_retries:
                logger.warning(f"Retry {retries}/{max_retries} after error: {str(e)}")
                time.sleep(delay)
    
    logger.error(f"Operation failed after {max_retries} retries. Last error: {str(last_error)}")
    return None
