document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide flash messages after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Copy command to clipboard functionality
    const commandCells = document.querySelectorAll('td code');
    commandCells.forEach(function(cell) {
        cell.style.cursor = 'pointer';
        cell.setAttribute('title', 'Click to copy');
        cell.addEventListener('click', function() {
            navigator.clipboard.writeText(cell.textContent).then(function() {
                // Show a temporary "Copied!" message
                const originalTitle = cell.getAttribute('title');
                cell.setAttribute('title', 'Copied!');
                setTimeout(function() {
                    cell.setAttribute('title', originalTitle);
                }, 2000);
            });
        });
    });
});
