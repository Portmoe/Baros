import logging
import re
from youtube_downloader import YouTubeDownloader

logger = logging.getLogger(__name__)

class CommandHandler:
    """Handler for processing user commands"""
    
    def __init__(self, whatsapp_bot):
        """Initialize the command handler
        
        Args:
            whatsapp_bot (WhatsAppBot): The WhatsApp bot instance
        """
        self.whatsapp_bot = whatsapp_bot
        self.youtube_downloader = YouTubeDownloader()
        
        # Define command patterns
        self.commands = {
            'help': r'^!help$',
            'youtube_download': r'^!ytdl\s+(.+)$',
            'youtube_info': r'^!ytinfo\s+(.+)$',
            'youtube_audio': r'^!ytaudio\s+(.+)$',
            'react': r'^!react\s+(.+)$',
            'status': r'^!status$'
        }
        
        logger.debug("Command Handler initialized")
    
    def process_command(self, sender, message):
        """Process a command from a user
        
        Args:
            sender (str): The sender's phone number
            message (str): The message text
            
        Returns:
            str or None: Response message or None if no response needed
        """
        try:
            # Track message
            self.whatsapp_bot.increment_received()
            
            # Check if message is a command
            if not message.startswith('!'):
                return None
                
            # Process based on command type
            if re.match(self.commands['help'], message):
                return self._help_command()
                
            elif re.match(self.commands['youtube_download'], message):
                match = re.match(self.commands['youtube_download'], message)
                url = match.group(1)
                return self._youtube_download_command(sender, url)
                
            elif re.match(self.commands['youtube_info'], message):
                match = re.match(self.commands['youtube_info'], message)
                url = match.group(1)
                return self._youtube_info_command(url)
                
            elif re.match(self.commands['youtube_audio'], message):
                match = re.match(self.commands['youtube_audio'], message)
                url = match.group(1)
                return self._youtube_audio_command(sender, url)
                
            elif re.match(self.commands['react'], message):
                match = re.match(self.commands['react'], message)
                reaction = match.group(1)
                return self._react_command(reaction)
                
            elif re.match(self.commands['status'], message):
                return self._status_command()
                
            else:
                return "Unknown command. Type !help for available commands."
                
        except Exception as e:
            logger.error(f"Error processing command: {str(e)}")
            return f"Error processing command: {str(e)}"
    
    def _help_command(self):
        """Handle the help command
        
        Returns:
            str: Help message with available commands
        """
        self.whatsapp_bot.increment_commands()
        
        help_text = (
            "🤖 *WhatsApp Bot Commands* 🤖\n\n"
            "*YouTube Commands*\n"
            "!ytdl [url] - Download YouTube video\n"
            "!ytaudio [url] - Download YouTube audio\n"
            "!ytinfo [url] - Get info about a YouTube video\n\n"
            "*Reaction Commands*\n"
            "!react [emoji/text] - Send a reaction\n\n"
            "*System Commands*\n"
            "!status - Show bot status\n"
            "!help - Show this help menu"
        )
        
        return help_text
    
    def _youtube_download_command(self, sender, url):
        """Handle YouTube download command
        
        Args:
            sender (str): The sender's phone number
            url (str): The YouTube URL
            
        Returns:
            str: Response message
        """
        self.whatsapp_bot.increment_commands()
        
        # First send a message that we're processing
        self.whatsapp_bot.send_message(sender, "⏳ Processing your download request. This may take a few moments...")
        
        # Download the video
        result = self.youtube_downloader.download_video(url)
        
        if result['status'] == 'success':
            self.whatsapp_bot.increment_downloads()
            
            # Send the file
            file_sent = self.whatsapp_bot.send_file(
                sender, 
                result['file_path'], 
                caption=f"Here's your video: {result['message']}"
            )
            
            if file_sent:
                return "✅ Video successfully sent!"
            else:
                return "⚠️ Video downloaded but couldn't be sent. The file might be too large."
        else:
            return f"❌ Download failed: {result['message']}"
    
    def _youtube_audio_command(self, sender, url):
        """Handle YouTube audio download command
        
        Args:
            sender (str): The sender's phone number
            url (str): The YouTube URL
            
        Returns:
            str: Response message
        """
        self.whatsapp_bot.increment_commands()
        
        # First send a message that we're processing
        self.whatsapp_bot.send_message(sender, "⏳ Processing your audio download request. This may take a few moments...")
        
        # Download the audio
        result = self.youtube_downloader.download_video(url, download_type='audio')
        
        if result['status'] == 'success':
            self.whatsapp_bot.increment_downloads()
            
            # Send the file
            file_sent = self.whatsapp_bot.send_file(
                sender, 
                result['file_path'], 
                caption=f"Here's your audio: {result['message']}"
            )
            
            if file_sent:
                return "✅ Audio successfully sent!"
            else:
                return "⚠️ Audio downloaded but couldn't be sent. The file might be too large."
        else:
            return f"❌ Download failed: {result['message']}"
    
    def _youtube_info_command(self, url):
        """Handle YouTube info command
        
        Args:
            url (str): The YouTube URL
            
        Returns:
            str: Response message with video info
        """
        self.whatsapp_bot.increment_commands()
        
        # Get video info
        info = self.youtube_downloader.get_video_info(url)
        
        if info['status'] == 'success':
            response = (
                "📺 *YouTube Video Information* 📺\n\n"
                f"*Title:* {info['title']}\n"
                f"*Creator:* {info['author']}\n"
                f"*Duration:* {info['length']}\n"
                f"*Views:* {info['views']}\n"
                f"*Published:* {info['publish_date']}\n\n"
                f"*Description:* {info['description']}\n\n"
                "Use !ytdl or !ytaudio to download this video."
            )
            return response
        else:
            return f"❌ Failed to get video info: {info['message']}"
    
    def _react_command(self, reaction):
        """Handle reaction command
        
        Args:
            reaction (str): The reaction text or emoji
            
        Returns:
            str: Response message with the reaction
        """
        self.whatsapp_bot.increment_commands()
        
        # Clean the reaction text
        reaction = reaction.strip()
        
        if not reaction:
            return "Please specify a reaction. Example: !react 👍"
        
        # Create different response formats based on reaction
        if len(reaction) == 1 and ord(reaction) > 127:  # Likely an emoji
            responses = [
                f"{reaction} {reaction} {reaction}",
                f"I react with {reaction}!",
                f"{reaction} Reaction sent {reaction}",
                f"You wanted me to react with {reaction}? Here you go!"
            ]
            import random
            return random.choice(responses)
        else:
            # Text reaction
            return f"*{reaction.upper()}!!!*"
    
    def _status_command(self):
        """Handle status command
        
        Returns:
            str: Response message with bot status
        """
        self.whatsapp_bot.increment_commands()
        
        stats = self.whatsapp_bot.get_stats()
        
        status_text = (
            "🤖 *Bot Status* 🤖\n\n"
            f"*Uptime:* {stats['uptime']}\n"
            f"*Started:* {stats['start_time']}\n\n"
            f"*Messages Received:* {stats['messages_received']}\n"
            f"*Messages Sent:* {stats['messages_sent']}\n"
            f"*Commands Processed:* {stats['commands_processed']}\n"
            f"*Downloads Completed:* {stats['downloads_completed']}\n"
            f"*Errors Encountered:* {stats['errors_encountered']}\n"
        )
        
        return status_text
