# WhatsApp Bot

A Python-based WhatsApp bot for automated responses, YouTube video downloads, music playback, and status/comment reactions.

## Features

- YouTube video downloads
- YouTube audio extraction
- Video information retrieval
- Automated responses
- Status and comment reactions
- Command-based interactions

## Installation

1. Clone this repository
2. Install the required dependencies:
   ```
   pip install flask gunicorn pytube requests
   ```
3. Configure your WhatsApp API credentials (see Configuration section)
4. Run the application:
   ```
   gunicorn --bind 0.0.0.0:5000 main:app
   ```

## Configuration

Before running the bot, you need to set up the following environment variables:

- `WHATSAPP_API_KEY`: Your WhatsApp API key
- `WHATSAPP_API_URL`: The WhatsApp API endpoint URL
- `WHATSAPP_PHONE_NUMBER_ID`: Your WhatsApp phone number ID
- `WHATSAPP_VERIFY_TOKEN`: A token to verify webhook requests
- `SESSION_SECRET`: A secret key for Flask sessions

## Commands

The bot supports the following commands:

- `!help` - Show available commands
- `!ytdl [url]` - Download YouTube video
- `!ytaudio [url]` - Download YouTube audio
- `!ytinfo [url]` - Get info about a YouTube video
- `!react [emoji/text]` - Send a reaction
- `!status` - Show bot status

## File Structure

- `app.py` - Main Flask application
- `command_handler.py` - Command processing logic
- `main.py` - Application entry point
- `whatsapp_bot.py` - WhatsApp API integration
- `youtube_downloader.py` - YouTube download functionality
- `utils.py` - Utility functions
- `static/` - Static files (CSS, JS)
- `templates/` - HTML templates

## License

This project is licensed under the MIT License - see the LICENSE file for details.